#ifndef _OPEN_H_
#define _OPEN_H_

/*
 * The prototypes of functions implemented in open.c
 */
int open_file(char *name, FILE **file_descriptor);

#endif
