#ifndef _READ_H_
#define _READ_H_

/*
 * The prototypes of functions implemented in read.c
 */
void read_file(FILE *file_descriptor, task_t task_list[], int *size);

#endif
