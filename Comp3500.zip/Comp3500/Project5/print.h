#ifndef _PRINT_H_
#define _PRINT_H_

/*
 * The prototypes of functions implemented in print.c
 */
void print_task_list(task_t task_list[], int size);

#endif
